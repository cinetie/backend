import Joi from '@hapi/joi';

export default Joi.object().keys({
  email: Joi.string().email({ minDomainSegments: 2 }).required()
    .error(() => 'You have to enter a valid email. Example: yourname@domain.com'),
  firstName: Joi.string().alphanum().min(3).max(30)
    .required()
    .error(() => 'You have to enter a valid first name. Example: Jane'),
  lastName: Joi.string().alphanum().min(3).max(30)
    .required()
    .error(() => 'You have to enter a valid last name. Example: Doe'),
  password: Joi.string().min(6).required()
    .error(() => 'You have to enter a valid password with more than 6 characters. Example: andela'),
}).options({ allowUnknown: false });
